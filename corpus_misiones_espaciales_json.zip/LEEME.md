# Corpus documental de misiones espaciales

Cada archivo en documentos/ contiene un documento en JSON UTF-8.
text contiene el texto del documento como una sola cadena, sin fragmentar.
doc_id identifica el documento de forma estable. url permite citar la fuente.
indice.json reúne el listado de archivos y metadatos. resumen.json incluye los
recuentos y cualquier incidencia.

En Wikipedia se conserva el cuerpo en inglés, incluidos los encabezados, las
listas, los pies de figuras y las tablas de contenido informativo. Se retiraron
los menús, las llamadas de cita, las secciones de referencias y enlaces externos,
y las direcciones web incrustadas. Se conserva el texto visible de los enlaces
en el cuerpo. Atribución: colaboradores de Wikipedia, por la URL de cada
artículo. Texto adaptado a formato plano, CC BY-SA 4.0:
https://creativecommons.org/licenses/by-sa/4.0/
https://en.wikipedia.org/wiki/Wikipedia:Copyrights

Los PDF se recorrieron de principio a fin con pdftotext. Se retiraron las
direcciones web, los números de página aislados y las cabeceras o pies
claramente repetidos. page_offsets indica los intervalos [start, end) del
texto de cada página en caracteres de Python. Las páginas sin texto tienen
intervalos vacíos. Se incluye la capa de texto disponible, incluido el OCR
original de los PDF históricos cuando existe. No se reproducen elementos
gráficos ni se rehace el OCR. Se conservan los documentos de todo el inventario,
incluidas distintas versiones cuando ya figuraban como documentos separados.

Para el hito de recuperación, partir de text y conservar doc_id al preprocesar
con spaCy. Al fragmentar, conservar el doc_id y la URL en cada fragmento.
